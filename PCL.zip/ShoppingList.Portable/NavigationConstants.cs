﻿namespace ShoppingList.Portable
{
    public static class NavigationConstants
    {
        public const string ListPage = "List";

        public const string EntryPage = "Entry";
    }
}
